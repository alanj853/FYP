#include <iostream>
#include <opencv2/opencv.hpp>
#include <PathController.hpp>
#include <UDP_Client.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core.hpp>

using namespace cv;

class Window {
      void CheckBox(int state) {
    	  int y=4;
}
public:
      int x;
     //void createCheckBox() { cv::createButton("Button 1", CheckBox, NULL, CV_CHECKBOX, 0); }
};
